package com.multi.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
