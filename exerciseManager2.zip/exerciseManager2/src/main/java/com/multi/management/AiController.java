package com.multi.management;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AiController {
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping("/write")
	public String write() {
		return "write";
	}
	
	@RequestMapping("/insert")
	public String insert() {
		return "insert";
	}
	
	@RequestMapping("/content")
	public String content() {
		System.out.println("aa");
		return "content";
	}
	
	@RequestMapping("/delete")
	public String delete() {
		return "delete";
	}
	
	@RequestMapping("/redirect")
	public String redirect() {
		return "redirect";
	}
	

	
}
